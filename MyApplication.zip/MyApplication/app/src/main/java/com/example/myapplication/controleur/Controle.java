package com.example.myapplication.controleur;

import android.util.Log;

import com.example.myapplication.modele.AccesDistant;
import com.example.myapplication.modele.Profil;

import org.json.JSONArray;

import java.util.Date;

public final class Controle {

    private static Controle instance = null;
    private Profil profil;
    private static AccesDistant accesDistant;

    private Controle() {
        super();
    }

    /**
     *Création de l'instance controleur
     * @return instance
     */
    public static final Controle getInstance() {

        if(instance == null){
            instance = new Controle();
            accesDistant = new AccesDistant();
            accesDistant.envoi("dernier", new JSONArray());
        }
        return instance;
    }

    /**
     * Création du profil
     * @param poids
     * @param taille en cm
     * @param age
     * @param sexe 1 = Homme / 0 = Femme
     */
    public void creerProfil(Integer poids, Integer taille, Integer age, Integer sexe){

        profil = new Profil(new Date(), poids, taille, age, sexe);

        Log.d("test", "******************" + profil.convertToJSONArray());

        accesDistant.envoi("enreg", profil.convertToJSONArray());
    }

    public float getImg() {

        return profil.getImg();
    }

    public String getMessage() {

        return profil.getMessage();
    }
}
