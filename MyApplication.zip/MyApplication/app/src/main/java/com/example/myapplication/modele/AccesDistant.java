package com.example.myapplication.modele;

import android.util.Log;

import com.example.myapplication.Outils.AccesHTTP;
import com.example.myapplication.Outils.AsyncResponse;

import org.json.JSONArray;

public class AccesDistant implements AsyncResponse {

    private static final String SERVERADDR = "http://192.168.0.15/coach/serveurcoach.php";

    public AccesDistant(){
        super();
    }

    //Retour du serveur distant
    @Override
    public void processFinish(String output) {
        Log.d("serveur", "**************output : " + output);

        String [] message = output.split("%");
        //Dans message[0] : soit "enreg" soit "erreur" soit "dernier"
        //Dans message[1] reste du message

        //Si il ya 2 cases
        if (message.length >1){

            if (message[0] == "enreg"){

                Log.d("enreg", "******************" + message[1]);
            }

            else if (message[0] == "dernier"){

                Log.d("dernier", "******************" + message[1]);
            }

            else { Log.d("erreur", "******************" + message[0] + message[1]); }
        }

        else {
            Log.d("vide", "**** Y arien...");
        }
    }

    public void envoi(String operation, JSONArray lesDonneesJSON) {

        AccesHTTP accesDonnees = new AccesHTTP();

        //Lien de délégation
        accesDonnees.delegate = this;

        //Ajout paramètres
        accesDonnees.addParam("operation", operation);
        accesDonnees.addParam("lesdonnees", lesDonneesJSON.toString());

        //Appel au serveur //appel le doInBackground de la classe AccesHTTP execute apartient a la classe mere
        accesDonnees.execute(SERVERADDR);
    }
}
