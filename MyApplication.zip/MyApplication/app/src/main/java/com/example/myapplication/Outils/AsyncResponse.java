package com.example.myapplication.Outils;

public interface AsyncResponse {

    void processFinish(String output);
}
