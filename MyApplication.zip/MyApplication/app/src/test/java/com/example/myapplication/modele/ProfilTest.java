package com.example.myapplication.modele;

import org.junit.Test;

import static org.junit.Assert.*;

public class ProfilTest {

    //Création profil
    private Profil profil = new Profil(67, 165, 35, 0);

    private Float img = (float)32.4;
    private String message = "trop élevé";

    @Test
    public void getImg() {
        assertEquals(img, profil.getImg(), (float)0.1);
    }

    @Test
    public void getMessage() {
        assertEquals(message, profil.getMessage());
    }
}